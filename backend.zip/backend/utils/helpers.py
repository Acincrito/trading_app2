# /backend/utils/helpers.py
def format_currency(value):
    return "{:.2f}".format(value)
