# backend/strategies/bot13.py

# Estratégia de Cobertura (Hedge)
# Executa operações contrárias para minimizar as perdas de uma estratégia principal.


from backend.database.models import Operation
from backend.database.db_setup import SessionLocal
from datetime import datetime
import random

class Bot13:
    def __init__(self, saldo_inicial=1000, trade_size=10, strategy_type="random"):
        """
        Inicializa o bot com saldo inicial, tamanho da operação e tipo de estratégia.
        
        :param saldo_inicial: Saldo inicial do bot.
        :param trade_size: Tamanho da operação.
        :param strategy_type: Tipo de estratégia ('random', 'coverage').
        """
        self.balance = saldo_inicial
        self.trade_size = trade_size
        self.strategy_type = strategy_type

    def run(self):
        """Executa a estratégia de trading com base no tipo escolhido."""
        if self.strategy_type == "random":
            self.random_strategy()
        elif self.strategy_type == "coverage":
            self.coverage_strategy()
        else:
            print("Estratégia desconhecida.")

    def generate_signal(self):
        """Gera sinal aleatório de compra ou venda."""
        return 'BUY' if random.choice([True, False]) else 'SELL'

    def random_strategy(self):
        """Estratégia baseada em sinais aleatórios de compra e venda."""
        signal = self.generate_signal()
        print(f"Executando operação com sinal: {signal}")

        if signal == 'BUY':
            self.buy(self.trade_size)
        elif signal == 'SELL':
            self.sell(self.trade_size)

    def coverage_strategy(self):
        """Estratégia de cobertura: executa compra e venda imediatamente para cobertura."""
        print("Executando operação de cobertura.")
        self.buy(self.trade_size)
        self.sell(self.trade_size)

    def buy(self, trade_size):
        """Executa uma compra."""
        self.balance -= trade_size
        print(f"Compra de {trade_size} unidades. Saldo restante: {self.balance}")
        self.record_operation('BUY', trade_size)

    def sell(self, trade_size):
        """Executa uma venda."""
        self.balance += trade_size
        print(f"Venda de {trade_size} unidades. Saldo restante: {self.balance}")
        self.record_operation('SELL', trade_size)

    def record_operation(self, trade_type, trade_size):
        """Grava a operação no banco de dados."""
        db = SessionLocal()
        try:
            operation = Operation(
                bot_name="Bot13",  # Nome do bot
                trade_type=trade_type,
                amount=trade_size,
                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                robot_id=1  # ID do robô
            )
            db.add(operation)
            db.commit()
        except Exception as e:
            print(f"Erro ao gravar operação no banco de dados: {e}")
        finally:
            db.close()

# Exemplo de uso:
if __name__ == "__main__":
    # Estratégia de sinais aleatórios
    bot_random = Bot13(saldo_inicial=1000, trade_size=10, strategy_type="random")
    bot_random.run()

    print("\n---- Operações de Cobertura ----\n")

    # Estratégia de cobertura
    bot_coverage = Bot13(saldo_inicial=1000, trade_size=10, strategy_type="coverage")
    bot_coverage.run()

def execute():
    """
    Função para executar a estratégia do Bot 
    Cria uma instância do Bot e executa a função run() para realizar as operações de compra e venda.
    """
    bot = Bot13(saldo_inicial=1000, trade_size=10, strategy_type="random")  # Corrigido para Bot13
    print("Bot Strategy Executando...")  # Exibe uma mensagem indicando que o bot foi iniciado
    bot.run()  # Chama o método run() que executa a lógica de trading (compra ou venda)
